<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Update Data</h1>

    <!-- card untuk tambah data -->
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Silahkan update data</div>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="hidden" name="id" id="uid" readonly value="<?= $member['uid']; ?>">
                        <div class="form-group">
                            <label for="name">UID</label>
                            <input type="text" class="form-control" name="uid" id="uid" value="<?= $member('uid'); ?>">
                            <?= form_error('uid', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="name">Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" id="nama" value="<?= $member('nama'); ?>">
                            <?= form_error('nama', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="email">ALamat</label>
                            <input type="text" class="form-control" name="alamat" id="alamat" value="<?= $member('alamat'); ?>">
                            <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="address">Nomor Polisi</label>
                            <input type="text" class="form-control" name="nopol" id="nopol" value="<?= $member('nopol'); ?>">
                            <?= form_error('nopol', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <a href="<?= base_url(); ?>" class="btn btn-success float-left" type="submit" name="submit">Kembali</a>
                        <button class="btn btn-primary float-right" type="submit" name="submit">Ubah Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- akhir card -->
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->