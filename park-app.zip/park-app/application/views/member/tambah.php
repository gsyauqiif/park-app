<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Data</h1>

    <!-- card untuk tambah data -->
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Silahkan tambah data</div>
                <div class="card-body">
                    <form action="<?= base_url('member/tambahData'); ?>" method="post">
                        <div class="form-group">
                            <label for="name">UID</label>
                            <input type="text" class="form-control" name="uid" id="uid" readonly value="<?= set_value('uid'); ?>">
                            <?= form_error('uid', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="name">Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" id="nama" value="<?= set_value('nama'); ?>">
                            <?= form_error('nama', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="email">Alamat</label>
                            <input type="text" class="form-control" name="alamat" id="alamat" value="<?= set_value('alamat'); ?>">
                            <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <div class="form-group">
                            <label for="address">Nomor Polisi</label>
                            <input type="text" class="form-control" name="nopol" id="nopol" value="<?= set_value('nopol'); ?>">
                            <?= form_error('address', '<small class="text-danger">', '</small>'); ?>
                        </div>
                        <a href="<?= base_url('member/index'); ?>" class="btn btn-success float-left" type="submit" name="submit">Kembali</a>
                        <button class="btn btn-primary float-right" type="submit" name="submit">Tambah Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- akhir card -->
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<script>
    function cekUID() {
        $.ajax({
            type: "GET",
            url: "<?= base_url('member/nfc'); ?>",
            cache: false,
            success: function(response) {
                console.log(response);
                $("#uid").val(response)
            }
        });
    }
    setInterval(cekUID, 2000);
</script>