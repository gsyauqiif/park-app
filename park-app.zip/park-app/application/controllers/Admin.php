<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        // $this->db->select_sum('nominal');
        // $data['total_donasi'] = $this->db->get('tbl_transaksi')->row_array();

        // $data['jumlah_member'] = $this->db->query('select * from tabel_member')->num_rows();

        // $data['total_kredit'] = $this->db->query("SELECT sum(nominal) as nominal FROM tabel_kredit where kredit = 'masuk'")->row_array();
        // $data['kas_keluar'] = $this->db->query("SELECT sum(nominal) as nominal FROM kas where tipe_kas = 'keluar'")->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/auth_header', $data);
        $this->load->view('templates/auth_footer');
    }
}
