<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['member'] = $this->db->get('tb_member')->result_array();

        $this->form_validation->set_rules('uid', 'UID', 'required');
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('nopol', 'Nomor Polisi', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('member/index', $data);
            $this->load->view('templates/footer');
            $this->load->view('templates/auth_header', $data);
            $this->load->view('templates/auth_footer');
        } else {
            $data = [
                'uid' => $this->input->post('uid'),
                'nama' => $this->input->post('alamat'),
                'alamat' => $this->input->post('alamat'),
                'nopol' => $this->input->post('alamat'),
            ];
            $this->db->insert('tb_member', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        New Donatur added!
      </div>');
            redirect('admin/donatur');
        }
    }

    public function tambahData()
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();



        $data['member'] = $this->db->get('tb_member')->result_array();

        $this->form_validation->set_rules('uid', 'UID', 'required');
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('nopol', 'Nomor Polisi', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('member/tambah', $data);
            $this->load->view('templates/footer');
            $this->load->view('templates/auth_header', $data);
            $this->load->view('templates/auth_footer');
        } else {
            $data = [
                'uid' => $this->input->post('uid'),
                'nama' => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'nopol' => $this->input->post('nopol'),
            ];
            $this->db->insert('tb_member', $data);
            $this->db->empty_table('tb_entry');
            $this->session->set_flashdata('message', 'Ditambahkan');
            redirect('member/index');
        }
    }

    public function detailData($uid)
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['member'] = $this->db->getDataById($uid);


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('member/detail', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/auth_header', $data);
        $this->load->view('templates/auth_footer');
    }

    public function updateData($uid)
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['member'] = $this->db->getDataById($uid);

        $this->form_validation->set_rules('uid', 'UID', 'required');
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('nopol', 'Nomor Polisi', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('member/update', $data);
            $this->load->view('templates/footer');
            $this->load->view('templates/auth_header', $data);
            $this->load->view('templates/auth_footer');
        } else {
            $data = [
                'uid' => $this->input->post('uid'),
                'nama' => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'nopol' => $this->input->post('nopol'),
            ];
            $this->db->where('id', $data);
            $this->session->set_flashdata('message', 'Diubah');
            redirect('member/index');
        }
    }

    public function deleteData($uid)
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->db->delete('tb_member', ['uid' => $uid]);
        $this->session->set_flashdata('message', 'Dihapus');
        redirect('member/index');
    }








    // METHOD BARU
    public function nfc()
    {
        $uid = $this->db->get('tb_entry')->result_array('uid');
        echo count($uid) > 0 ? $uid[0]['uid'] : '';
    }

    public function rest()
    {
        $uid = $this->input->post('uid');
        $this->db->insert('tb_entry', ['uid' => $uid]);
    }
}
