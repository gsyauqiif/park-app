<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Controller
{

    public function top_up()
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('transaksi/top_up', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/auth_header', $data);
        $this->load->view('templates/auth_footer');
    }

    public function pengguna()
    {
        $data['title'] = 'Kelola Administrator - Transaksi Pengguna - EPARKING';
        $data['tabel_admin'] = $this->db->get_where('tabel_admin', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('transaksi/pengguna', $data);
        $this->load->view('templates/footer');
        $this->load->view('templates/auth_header', $data);
        $this->load->view('templates/auth_footer');
    }
}
